//
//  JaredFramework.h
//  JaredFramework
//
//  Created by Jared Derulo on 4/18/16.
//  Copyright © 2016 Zeke Snider. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for JaredFramework.
FOUNDATION_EXPORT double JaredFrameworkVersionNumber;

//! Project version string for JaredFramework.
FOUNDATION_EXPORT const unsigned char JaredFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JaredFramework/PublicHeader.h>


